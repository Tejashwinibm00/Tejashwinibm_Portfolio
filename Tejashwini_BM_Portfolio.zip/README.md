# Tejashwini B M — Data Science Portfolio

A responsive premium portfolio website built with HTML, CSS and JavaScript.

## Run locally
1. Install Node.js 18 or newer.
2. Run `npm start` in this folder.
3. Open `http://localhost:3000` (or `http://tejashwinibm` after configuring the local hostname below).

### Local hostname

Run Notepad as Administrator and open `C:\Windows\System32\drivers\etc\hosts`. Add this line:

```text
127.0.0.1 tejashwinibm
```

Then restart the server and open `http://tejashwinibm`.

## Publish publicly
1. Push this folder to a GitHub repository.
2. On [Render](https://render.com), create a new **Web Service** from that repository.
3. Use the repository root as the project directory. Render can use the included `render.yaml`, or set the start command to `npm start` manually.
4. Open the `onrender.com` URL to verify the portfolio.

### Use `tejashwinibm.com`
1. Buy `tejashwinibm.com` from a domain registrar if you do not already own it.
2. In Render, open the service and choose **Settings → Custom Domains → Add Custom Domain**.
3. Add both `tejashwinibm.com` and `www.tejashwinibm.com`.
4. Copy the DNS records Render displays into your registrar's DNS settings.
5. Wait for DNS propagation and confirm HTTPS is active.

The final resume link will be `https://tejashwinibm.com`.

## Structure
- `app.html` — content and sections
- `style.css` — responsive styling and animations
- `script.js` — scroll reveal, progress bar, mobile menu and cursor effect
- `server.js` — lightweight production HTTP server
- `package.json` — start command and Node.js version
